package com.example.demo.model;

public enum TypeUser {
	MEDIC,PACIEN
}
