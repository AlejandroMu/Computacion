package com.example.demo.model;

public enum GenerUser {
	MALE,FEMALE
}
