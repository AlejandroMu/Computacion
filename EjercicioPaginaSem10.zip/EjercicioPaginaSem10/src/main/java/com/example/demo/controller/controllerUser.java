package com.example.demo.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.hibernate.usertype.UserType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.GenerUser;
import com.example.demo.model.TypeUser;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

@Controller
public class controllerUser {
	
	
	@Autowired
	private UserRepository serviceUser;
	@PostConstruct
	public void init() {
		User p1 = new User();

        p1.setName("Adella Haley");
        p1.setEmail("Adella.Ledner@hotmail.com");
        p1.setBorn(new Date("1999/08/02"));
        p1.setGenero(GenerUser.FEMALE);
        p1.setTipo(TypeUser.PACIEN);

        User p2 = new User();
        p2.setName("Mario Joaquie");
        p2.setEmail("Misty98@yahoo.com");
        p2.setBorn(new Date("1999/7/13"));
        p2.setGenero(GenerUser.FEMALE);
        p2.setTipo(TypeUser.PACIEN);

        User p3 = new User();
        p3.setName("Paul Mirage");
        p3.setEmail("Maud38@yahoo.com");
        p3.setBorn(new Date("1970/5/15"));
        p3.setGenero(GenerUser.FEMALE);
        p3.setTipo(TypeUser.PACIEN);

        serviceUser.save(p1);
        serviceUser.save(p2);
        serviceUser.save(p3);

        // MEDICS
        User m1 = new User();

        m1.setName("David Nielse");
        m1.setEmail("Davin.Hansen68@gmail.com");
        m1.setBorn(new Date("1985/2/13"));
        m1.setGenero(GenerUser.FEMALE);
        m1.setTipo(TypeUser.MEDIC);

        User m2 = new User();
        m2.setName("Maria Salera");
        m2.setEmail("Salma12@gmail.com");
        m2.setBorn(new Date("1980/11/24"));
        m2.setGenero(GenerUser.FEMALE);
        m2.setTipo(TypeUser.MEDIC);

        User m3 = new User();
        m3.setName("Carlos Liason");
        m3.setEmail("Cali82@yahoo.com");
        m3.setBorn(new Date("1992/3/18"));
        m3.setGenero(GenerUser.FEMALE);
        m3.setTipo(TypeUser.MEDIC);

        serviceUser.save(m1);
        serviceUser.save(m2);
        serviceUser.save(m3);
	}
	
	@GetMapping("/")
	public String index() {
		
		return "index";
	}
	
	@GetMapping("/addUser")
	public String addUser(Model model) {
		User newUser=new User();
		model.addAttribute("user",newUser);
		
		model.addAttribute("generos",GenerUser.values());
		model.addAttribute("tipos",TypeUser.values());
		return "crearUser";
	}
	
	
	@PostMapping("/guardar/")
	public String guardarUser(@ModelAttribute User users) {
		
		serviceUser.save(users);
		
		return "redirect:/listarUsuarios";
	}
	@PostMapping("/guardar/{id}")
	public String guardarUser(@ModelAttribute User users,@PathVariable Long id) {
		User u=serviceUser.findById(id).get();
		u.setBorn(users.getBorn());
		u.setEmail(users.getEmail());
		u.setGenero(users.getGenero());
		u.setName(users.getName());
		u.setTipo(users.getTipo());
		serviceUser.save(u); 	 
		return "redirect:/listarUsuarios";
	}
	@GetMapping("/listarUsuarios")
	public String listar(Model model) {
		ArrayList<User> lista=new ArrayList<User>();
		Iterable<User> it=serviceUser.findAll();
		for (Iterator iterator = it.iterator(); iterator.hasNext();) {
			User user = (User) iterator.next();
			lista.add(user);
			
		}
		model.addAttribute("usuarios",lista);
		return "listar";
	}
	
	@GetMapping("/filtro/{user}")
	public String filtro(@PathVariable TypeUser user, Model model) {
		List<User> lsita=serviceUser.findByTipo(user);
		model.addAttribute("usuarios",lsita);
		return "listar";
	}
	
	@GetMapping("/editar/{user}")
	public String editar(@PathVariable Long user, Model model) {
		User lsita=serviceUser.findById(user).get();
		model.addAttribute("user",lsita);
		
		model.addAttribute("generos",GenerUser.values());
		model.addAttribute("tipos",TypeUser.values());
		return "editarUser";
	}
	@GetMapping("/eliminar/{user}")
	public String eliminar(@PathVariable Long user) {
		serviceUser.deleteById(user);
		return "redirect:/listarUsuarios";
	}
	
	
	
	
}
