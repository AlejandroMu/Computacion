package com.example.demo.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.Cita;
import com.example.demo.model.GenerUser;
import com.example.demo.model.TypeUser;
import com.example.demo.model.User;
import com.example.demo.repository.CitaRepository;
import com.example.demo.repository.UserRepository;

@Controller
public class controllerCita {
	
	@Autowired
	private CitaRepository serviceCita;
	
	@Autowired
	private UserRepository serviceUser;
	@GetMapping("/listarCitas")
	public String listarCitas(Model model) {
		ArrayList<Cita> lista=new ArrayList<Cita>();
		Iterable<Cita> it=serviceCita.findAll();
		for (Iterator iterator = it.iterator(); iterator.hasNext();) {
			Cita cita = (Cita) iterator.next();
			lista.add(cita);
			
		}
		model.addAttribute("citas",lista);
		return "listarCitas";
	}
	@GetMapping("/addCita")
	public String crearCita(Model model) {
		Cita nueva=new Cita();
		model.addAttribute("cita",nueva);
		model.addAttribute("patients",serviceUser.findByTipo(TypeUser.PACIEN));
		model.addAttribute("medics",serviceUser.findByTipo(TypeUser.MEDIC));
		return "crearCitas";
	}
	@PostMapping("/saveC")
	public String guardarUser(@ModelAttribute Cita cita) {
		
		serviceCita.save(cita);
		return "redirect:/listarCitas";
	}
	
	
	@GetMapping("/editarC/{cita}")
	public String editar(@PathVariable Long cita, Model model) {
		Cita lsita=serviceCita.findById(cita).get();
		model.addAttribute("cita",lsita);
		
		model.addAttribute("patients",serviceUser.findByTipo(TypeUser.PACIEN));
		model.addAttribute("medics",serviceUser.findByTipo(TypeUser.MEDIC));
		return "editarCita";
	}
	@GetMapping("/eliminarC/{cita}")
	public String eliminar(@PathVariable Long cita) {
		serviceCita.deleteById(cita);
		return "redirect:/listarCitas";
	}
	@PostMapping("/saveC/{id}")
	public String guardarUser(@ModelAttribute Cita users,@PathVariable Long id) {
		Cita u=serviceCita.findById(id).get();
		u.setDate(users.getDate());
		u.setMedic(users.getMedic());
		u.setPatient(users.getPatient());
		u.setTime(users.getTime());
		serviceCita.save(u); 	 
		return "redirect:/listarCitas";
	}
	
	
	
	
}
