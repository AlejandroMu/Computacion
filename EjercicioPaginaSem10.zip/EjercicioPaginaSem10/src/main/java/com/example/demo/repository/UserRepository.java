package com.example.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.demo.model.TypeUser;
import com.example.demo.model.User;


@Repository
public interface UserRepository extends CrudRepository<User, Long> {

	
	List<User> findByName(String name);
	List<User> findByTipo(TypeUser tipo);
	
}
