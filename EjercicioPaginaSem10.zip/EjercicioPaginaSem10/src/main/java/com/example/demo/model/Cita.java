package com.example.demo.model;

import java.time.LocalTime;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;
import lombok.NonNull;
@Data
@Entity
public class Cita {

		@Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Long id;

	    @ManyToOne
	    private User patient;

	    @ManyToOne
	    private User medic;

	    @DateTimeFormat(pattern = "yyyy-MM-dd")  
	    @NotNull
	    private Date date;


	    @DateTimeFormat(pattern="HH:mm")
	    @NotNull
	    private LocalTime time;
	
	    
	    public String toString() {
	    	return id+"";
	    }
}
