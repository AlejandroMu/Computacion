package co.edu.icesi.ci.junit.spring;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.LoggerFactory;

import static org.junit.Assert.*;

import static org.hamcrest.CoreMatchers.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import co.edu.icesi.ci.junit.spring.main.AppConfig;
import co.edu.icesi.ci.junit.spring.model.Order;
import co.edu.icesi.ci.junit.spring.service.SampleService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AppConfig.class, loader = AnnotationConfigContextLoader.class)
public class JUnitSpringExample {

	@Autowired
	private SampleService sampleService;


	private static final Logger log = LoggerFactory.getLogger(JUnitSpringExample.class);

	@BeforeClass
	public static void setUp() {
		log.info("-----> SETUP <-----");
	}

	@Test
	public void testSampleServiceGetAccountDescription() {
		// Check if the return description has a 'Description:' string.
		assertTrue(sampleService.getOrderDescription(0).contains("Description:"));
	}

	@Test
	public void testSampleServiceGetAccountCode() {
		// Check if the return description has a 'Code:' string.
		assertTrue(sampleService.getOrderStringCode(0).contains("Code:"));
	}

	@Test
	public void testSampleServiceCreateNewOrder() {
		Order newOrder = new Order();
		newOrder.setSecurityCode("XYZ");
		newOrder.setDescription("Description");
		if (newOrder != null) {
			assertThat(sampleService.createOrder(newOrder), instanceOf(Order.class));
			assertNotNull("Security isn't null", newOrder.getSecurityCode());
			assertNotNull("Description isn't not null", newOrder.getDescription());
		}

		assertNotNull("New Order is not null", newOrder);

	}

	@Test
	public void testSampleServiceGetOrder() {

		Order existingOrder = sampleService.getOrder(0);

		if (existingOrder != null) {
			assertThat(sampleService.getOrder(0), instanceOf(Order.class));
			assertNotNull("Security isn't null", existingOrder.getSecurityCode());
			assertNotNull("Description isn't null", existingOrder.getDescription());
		}

		assertNotNull("Object is not null", existingOrder);
	}

	@AfterClass
	public static void afterTest() {
		log.info("-----> DESTROY <-----");
	}
}
