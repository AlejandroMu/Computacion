package co.edu.icesi.ci.junit.spring.service;

import co.edu.icesi.ci.junit.spring.model.Order;

public interface SampleService {

	public String getOrderDescription(int id);
	public String getOrderStringCode(int id);
	public Order getOrder(int id);
	public Order createOrder(Order order);
	public Order updateOrder (Order order);
	public Order deleteOrder (Order order);
	
	
}
